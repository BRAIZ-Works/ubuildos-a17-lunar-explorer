# Public Scope and Safety

**BRAIZ Works™ · A17 Lunar Explorer**

Version: 1.3.0
Currentness: 2026-09-30

## Included

- Digital engineering documentation.
- CAD, printable, STEP, STL, and 3MF files included in this package.
- Drawings and renders.
- Bill of materials and sourcing information.
- OpenRocket/modeling artifacts and modeled trajectory outputs.
- Original project graphics.
- Public claims, rights, and provenance records.

## Not established by this package

- Fabrication completion.
- Ground-test or physical-validation completion.
- Flight-test completion.
- Measured real-world performance.
- Guaranteed performance.
- NASA affiliation, endorsement, approval, sponsorship, official status, or official-replica status.

## Physical-use boundary

Only commercially certified hobby rocket motors are contemplated by the documentation. This package contains no motor-fabrication instructions, propellant recipes, or motor-modification instructions.

Before physical use, verify current applicable site, jurisdiction, safety-code, motor-certification, and supervision requirements. A digital engineering release does not replace real-world safety review.
