# A17 Lunar Explorer | Engineering reference

**BRAIZ Works™ · A17 Lunar Explorer**

Version: 1.3.0  
Currentness: 2026-09-30

This package contains digital engineering materials for an independent educational model-rocket project. The documentation is a design and inspection reference. It does not establish a built or flight-tested article.

## Choose a starting point

| Need | Open |
| --- | --- |
| Understand the design, parts, sequence, and limitations | `01_DOCS/MASTER_BUILD_BOOK.pdf` |
| Get a short orientation to the document set | `01_DOCS/QUICK_START.pdf` |
| Review hazards and stop conditions | `01_DOCS/SAFETY_GUIDE.pdf` and `01_DOCS/FMEA_HAZARD_REGISTER.pdf` |
| Inspect the modeled engineering inputs | `02_CAD/`, `03_SIMULATION/`, and `04_BOM/` |
| Check provenance and use boundaries | `06_PUBLIC_PROVENANCE/` and the outer release's `RIGHTS_AND_USE.md` |

The eleven documents in `01_DOCS/` are provided as paired editable DOCX and reading PDF files. Their technical values and safety limitations were carried forward from the preceding release; this edition improves presentation.

## Evidence boundary

Digital engineering is complete for the released scope. Fabrication, physical validation, and flight validation have not been performed. Simulation outputs are modeled, not measured flight data or performance guarantees.

This digital package does not authorize a physical build or launch. Independently verify current site rules, applicable law and safety codes, certified commercial motors, and appropriate supervision before real-world use.

A17 Lunar Explorer is independent and is not affiliated with, sponsored by, approved by, or endorsed by NASA. It is not an official NASA, Artemis, or SLS replica.
