import cadquery as cq
from cadquery import exporters
from pathlib import Path
import math, json, shutil

ROOT = Path(__file__).resolve().parents[2]
STEP = ROOT/'02_CAD'/'STEP'; STL = ROOT/'02_CAD'/'STL'; MF3 = ROOT/'02_CAD'/'3MF'; DWG = ROOT/'02_CAD'/'DRAWINGS'
for p in (STEP, STL, MF3, DWG): p.mkdir(parents=True, exist_ok=True)

# Canonical dimensions (mm). Intentionally original, not scale NASA/SLS geometry.
D = {
    'body_od': 41.6,
    'body_id': 40.5,
    'body_wall': 0.55,
    'nose_length': 190.0,
    'nose_shoulder_length': 48.0,
    'nose_wall': 1.0,
    'forward_tube_length': 250.0,
    'center_tube_length': 300.0,
    'aft_tube_length': 250.0,
    'coupler_length': 70.0,
    'coupler_wall': 0.9,
    'coupler_clearance': 0.25,
    'fin_can_length': 155.0,
    'fin_can_wall': 1.2,
    'fin_can_clearance': 0.35,
    'fin_count': 3,
    'fin_root_chord': 105.0,
    'fin_tip_chord': 40.0,
    'fin_span': 54.0,
    'fin_sweep': 35.0,
    'fin_thickness': 2.0,
    'motor_mount_od': 24.8,
    'motor_mount_id': 24.1,
    'motor_mount_length': 95.0,
    'launch_lug_id': 4.9,
    'launch_lug_od': 7.5,
    'launch_lug_length': 45.0,
    'parachute_diameter': 600.0,
}

# Common helpers

def shell_cylinder(od, id_, length):
    return cq.Workplane('XY').circle(od/2).circle(id_/2).extrude(length)

def export_all(name, obj):
    exporters.export(obj, str(STEP/f'{name}.step'))
    exporters.export(obj, str(STL/f'{name}.stl'), tolerance=0.05, angularTolerance=0.1)
    exporters.export(obj, str(MF3/f'{name}.3mf'))

# Nose cone: smooth hollow tangent-ogive-like loft, original geometry.
def ogive_radius_from_tip(x, R, L):
    rho=(R*R+L*L)/(2*R)
    return math.sqrt(max(0.0, rho*rho-(L-x)*(L-x))) + R-rho

R=D['body_od']/2
L=D['nose_length']
# z=0 at base; z=L at tip. Use multiple circular sections for smooth loft.
stations=list(range(0,181,20))+[188,190]
wp=cq.Workplane('XY')
last=0
for i,z in enumerate(stations):
    x=L-z
    r=max(0.7, ogive_radius_from_tip(x,R,L))
    if i==0:
        wp=wp.circle(r)
    else:
        wp=wp.workplane(offset=z-last).circle(r)
    last=z
nose_outer=wp.loft(combine=True, ruled=False)
# Inner cavity leaves ~1.35 mm wall and solid tip.
inner_stations=[0,20,40,60,80,100,120,140,160,176,184]
wi=cq.Workplane('XY')
last=0
for i,z in enumerate(inner_stations):
    x=L-z
    r=max(0.5, ogive_radius_from_tip(x,max(1.0,R-D['nose_wall']),L-3.0))
    if i==0:
        wi=wi.circle(r)
    else:
        wi=wi.workplane(offset=z-last).circle(r)
    last=z
inner=wi.loft(combine=True, ruled=False)
nose=nose_outer.cut(inner)
# Shoulder extends aft from base.
shoulder_od=D['body_id']-2*D['coupler_clearance']
shoulder_id=max(1.0, shoulder_od-2*D['nose_wall'])
shoulder=cq.Workplane('XY').workplane(offset=-D['nose_shoulder_length']).circle(shoulder_od/2).circle(shoulder_id/2).extrude(D['nose_shoulder_length'])
nose=nose.union(shoulder)
# Internal harness bridge inside shoulder; 4 mm lanyard hole, kept out of body/recovery path.
bridge=cq.Workplane('XY').box(shoulder_od-5.0,6.0,4.0).translate((0,0,-24.0))
hole=cq.Workplane('XY').circle(2.1).extrude(8.0).translate((0,0,-28.0))
bridge=bridge.cut(hole)
nose=nose.union(bridge)
export_all('A17-P001_NOSE_CONE_R2', nose)

# Coupler
coupler_od=D['body_id']-2*D['coupler_clearance']; coupler_id=coupler_od-2*D['coupler_wall']
coupler=shell_cylinder(coupler_od,coupler_id,D['coupler_length'])
# center stop ring small external ridge
stop=cq.Workplane('XY').circle((D['body_od']+0.2)/2).circle(coupler_id/2).extrude(2.0).translate((0,0,D['coupler_length']/2-1.0))
coupler=coupler.union(stop)
export_all('A17-P002_STRUCTURAL_COUPLER_R1',coupler)

# Fin can sleeve + 3 fins. Sleeve slides over aft body tube and is bonded.
fc_id=D['body_od']+2*D['fin_can_clearance']; fc_od=fc_id+2*D['fin_can_wall']
fin_can=shell_cylinder(fc_od,fc_id,D['fin_can_length'])
# Fin polygon in XZ, extruded tangentially in Y and rotated around Z
root=D['fin_root_chord']; tip=D['fin_tip_chord']; span=D['fin_span']; sweep=D['fin_sweep']; th=D['fin_thickness']
# local polygon: axial z vs radial x, rear at z=0. Fin extends outward +X from body radius.
fin_root_r=fc_od/2-1.5
poly=[(fin_root_r,0),(fin_root_r,root),(fc_od/2+span,root-sweep),(fc_od/2+span,root-sweep-tip)]
fin2d=cq.Workplane('XZ').polyline(poly).close()
fin=fin2d.extrude(th/2,both=True)
# translate fin root start 8 mm above aft end
fin=fin.translate((0,0,8.0))
for a in [0,120,240]:
    fin_can=fin_can.union(fin.rotate((0,0,0),(0,0,1),a))
# launch lug boss on sleeve, opposite one fin (60 degrees)
lug=shell_cylinder(D['launch_lug_od'],D['launch_lug_id'],D['launch_lug_length']).rotate((0,0,0),(1,0,0),90).translate((0,fc_od/2+1.2,D['fin_can_length']*0.52))
fin_can=fin_can.union(lug)
export_all('A17-P003_FIN_CAN_R4',fin_can)

# Motor centering rings - printed only as alignment/fit-check option; flight BOM recommends fiber/cardboard rings.
ring_outer=D['body_id']-0.4
ring_inner=D['motor_mount_od']+0.3
ring=shell_cylinder(ring_outer,ring_inner,3.0)
export_all('A17-P004_MOTOR_CENTERING_RING_OPTIONAL_R1',ring)

# Tube alignment jig: two saddles with central gap
base=cq.Workplane('XY').box(110,55,8)
channel=cq.Workplane('XY').circle((D['body_od']+0.6)/2).extrude(20).translate((0,0,-6))
jig=base.cut(channel)
# slot for square/alignment reference
jig=jig.cut(cq.Workplane('XY').box(3,60,20).translate((0,0,0)))
export_all('A17-T001_TUBE_ALIGNMENT_JIG_R1',jig)

# Fin alignment gauge: annular disk with three radial slots sized for fin thickness.
gauge=cq.Workplane('XY').circle((D['body_od']+2*D['fin_span']+18)/2).circle((D['body_od']+1.0)/2).extrude(4)
for a in [0,120,240]:
    slot=cq.Workplane('XY').box(D['fin_span']+18,D['fin_thickness']+0.45,8).translate(((D['body_od']/2)+(D['fin_span']/2),0,0)).rotate((0,0,0),(0,0,1),a)
    gauge=gauge.cut(slot)
export_all('A17-T002_FIN_ALIGNMENT_GAUGE_R1',gauge)

# Printer tolerance coupon: three connected fit rings around nominal tube OD.
coupon=None
for i,delta in enumerate([-0.4,0.0,0.4]):
    x=(i-1)*60.0
    ring=cq.Workplane('XY').circle(25.0).circle((D['body_od']+delta)/2).extrude(5).translate((x,0,0))
    coupon=ring if coupon is None else coupon.union(ring)
# bridges keep the three gauges as one printable tool while preserving full circles.
for x in [-30,30]:
    coupon=coupon.union(cq.Workplane('XY').box(20,8,5).translate((x,0,2.5)))
export_all('A17-T003_TOLERANCE_COUPON_R2',coupon)

# Recovery packing tool: simple rounded mandrel for parachute folds, no flight use.
pack=cq.Workplane('XY').circle(12).extrude(110).faces('>Z').fillet(3)
export_all('A17-T004_RECOVERY_PACKING_TOOL_R1',pack)

# Display stand: ring cradle on rectangular base.
stand_base=cq.Workplane('XY').box(150,90,8)
post=cq.Workplane('XY').box(15,15,70).translate((0,0,39))
cradle=cq.Workplane('YZ').circle(32).circle(24).extrude(15).translate((-7.5,0,78))
stand=stand_base.union(post).union(cradle)
export_all('A17-D001_DISPLAY_STAND_R1',stand)

# A lightweight classroom cutaway nose shell: 120 degree sector approximation by cutting half-space twice.
cutaway=nose
cut1=cq.Workplane('YZ').box(100,300,300).translate((25,0,80))
cutaway=cutaway.cut(cut1)
export_all('A17-E001_NOSE_CUTAWAY_R1',cutaway)

# Canonical assembly solids for neutral CAD: simple thin-wall tube solids + printed parts.
def tube(od,id_,L,z):
    return shell_cylinder(od,id_,L).translate((0,0,z))
# Assembly axis uses +Z from aft toward nose for neutral convenience.
aft=tube(D['body_od'],D['body_id'],D['aft_tube_length'],0)
center=tube(D['body_od'],D['body_id'],D['center_tube_length'],D['aft_tube_length'])
forward=tube(D['body_od'],D['body_id'],D['forward_tube_length'],D['aft_tube_length']+D['center_tube_length'])
# fin_can already starts at z 0
# Rotate nose from its +Y axial orientation into +Z, then locate.
nose_z=nose.translate((0,0,D['aft_tube_length']+D['center_tube_length']+D['forward_tube_length']))
assembly=aft.union(center).union(forward).union(fin_can).union(nose_z)
exporters.export(assembly,str(STEP/'A17_FULL_ASSEMBLY_REFERENCE_R6.step'))
exporters.export(assembly,str(STL/'A17_FULL_ASSEMBLY_REFERENCE_R6.stl'),tolerance=0.1,angularTolerance=0.15)
exporters.export(assembly,str(MF3/'A17_FULL_ASSEMBLY_REFERENCE_R6.3mf'))

# Dimension / interface record
spec={
  'schema':'A17_CAD_INTERFACE_SPEC_V1',
  'units':'mm',
  'revision':'R6',
  'dimensions':D,
  'interfaces':{
    'body_to_fin_can':{'nominal_clearance_per_side':D['fin_can_clearance'],'bonded':True},
    'body_to_coupler':{'nominal_clearance_per_side':D['coupler_clearance'],'bonded_where_permanent':True},
    'nose_shoulder_to_body':{'nominal_clearance_per_side':D['coupler_clearance'],'removable':True},
    'motor_mount':{'commercial_motor_diameter_class_mm':24,'tube_od':D['motor_mount_od'],'thermal_note':'Use paper/fiber motor tube and nonprinted flight centering rings; printed ring is fit-check/optional only.'}
  }
}
(ROOT/'02_CAD'/'A17_CAD_INTERFACE_SPEC_R6.json').write_text(json.dumps(spec,indent=2))

# Produce simple orthographic SVG drawing directly from CadQuery projection where possible.
try:
    exporters.export(assembly, str(DWG/'A17_FULL_ASSEMBLY_ORTHO_R6.svg'))
except Exception as e:
    (DWG/'SVG_EXPORT_NOTE.txt').write_text(str(e))
print(json.dumps(spec,indent=2))
